package forer.FlightsAndMovies;

public class MovieID {
    int id;


    public MovieID(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
